import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

const isNativeAndroid = Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';

function toNotificationId(noteId) {
  // Android notification IDs must be positive 32-bit integers.
  let hash = 0;
  const value = String(noteId);
  for (let i = 0; i < value.length; i++) {
    hash = ((hash * 31) + value.charCodeAt(i)) | 0;
  }
  return Math.abs(hash) || 1;
}

async function ensurePermission() {
  if (!isNativeAndroid) return false;
  let permission = await LocalNotifications.checkPermissions();
  if (permission.display !== 'granted') {
    permission = await LocalNotifications.requestPermissions();
  }
  return permission.display === 'granted';
}

async function cancel(noteId) {
  if (!isNativeAndroid || noteId == null) return;
  try {
    await LocalNotifications.cancel({ notifications: [{ id: toNotificationId(noteId) }] });
  } catch (error) {
    // It is normal for a notification to have already fired or not exist.
    console.warn('MyNoteList: could not cancel notification', error);
  }
}

async function schedule(note) {
  if (!isNativeAndroid || !note || note.id == null) return;
  await cancel(note.id);
  if (!note.reminder) return;

  const at = new Date(note.reminder);
  if (Number.isNaN(at.getTime()) || at.getTime() <= Date.now()) return;
  const allowed = await ensurePermission();
  if (!allowed) {
    console.warn('MyNoteList: notification permission was not granted');
    return;
  }

  const title = (note.title || '').trim() || 'MyNoteList';
  const body = (note.body || '').trim() || 'У вас є нагадування';
  await LocalNotifications.schedule({
    notifications: [{
      id: toNotificationId(note.id),
      title,
      body,
      schedule: { at, allowWhileIdle: true },
      extra: { noteId: String(note.id) },
      autoCancel: true
    }]
  });
}

async function syncAll(notes) {
  if (!isNativeAndroid || !Array.isArray(notes)) return;
  const permission = await LocalNotifications.checkPermissions();
  if (permission.display !== 'granted') return;
  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length) {
    await LocalNotifications.cancel({ notifications: pending.notifications });
  }
  for (const note of notes) {
    if (note && note.reminder && new Date(note.reminder).getTime() > Date.now()) {
      await schedule(note);
    }
  }
}

window.MyNoteListReminders = {
  isNativeAndroid,
  schedule,
  cancel,
  syncAll
};
