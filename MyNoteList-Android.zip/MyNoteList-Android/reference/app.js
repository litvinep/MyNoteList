document.addEventListener("DOMContentLoaded", function() {
var translations = {
uk: { appTitle:"MyNoteList", tabNotes:"Нотатки", tabShop:"Покупки", phTitle:"Заголовок нотатки", phBody:"Текст нотатки...", phShop:"Що купити?", remToggle:"⏰ Додати нагадування", badgeYes:"є", btnSetRem:"Встановити нагадування", btnAddNote:"Додати нотатку", btnSaveNote:"Зберегти зміни", btnCancel:"Скасувати редагування", btnAdd:"Додати", btnClearBought:"Очистити куплені", setLang:"Мова", setTheme:"Кольорова тема", setMode:"Режим", setDark:"Темний режим", emptyNotes:"Поки що немає нотаток", emptyShop:"Список порожній", noTitle:"(без заголовка)", alertPast:"Цей час уже минув — оберіть майбутній", alertRemove:"Прибрати" },
ru: { appTitle:"MyNoteList", tabNotes:"Заметки", tabShop:"Покупки", phTitle:"Заголовок заметки", phBody:"Текст заметки...", phShop:"Что купить?", remToggle:"⏰ Добавить напоминание", badgeYes:"есть", btnSetRem:"Установить напоминание", btnAddNote:"Добавить заметку", btnSaveNote:"Сохранить изменения", btnCancel:"Отменить редактирование", btnAdd:"Добавить", btnClearBought:"Очистить купленные", setLang:"Язык", setTheme:"Цветовая тема", setMode:"Режим", setDark:"Темный режим", emptyNotes:"Пока нет заметок", emptyShop:"Список пуст", noTitle:"(без заголовка)", alertPast:"Это время уже прошло — выберите будущее", alertRemove:"Убрать" },
en: { appTitle:"MyNoteList", tabNotes:"Notes", tabShop:"Shopping", phTitle:"Note title", phBody:"Note text...", phShop:"What to buy?", remToggle:"⏰ Add reminder", badgeYes:"yes", btnSetRem:"Set reminder", btnAddNote:"Add note", btnSaveNote:"Save changes", btnCancel:"Cancel edit", btnAdd:"Add", btnClearBought:"Clear bought", setLang:"Language", setTheme:"Color theme", setMode:"Mode", setDark:"Dark mode", emptyNotes:"No notes yet", emptyShop:"List is empty", noTitle:"(no title)", alertPast:"This time has passed — choose future", alertRemove:"Remove" }
};
var currentLang = localStorage.getItem('lang') || 'uk';
function t(key) { return translations[currentLang][key] || translations['uk'][key] || key; }
function updateLanguage() {
var els = document.querySelectorAll('[data-i18n]');
for (var i = 0; i < els.length; i++) {
var key = els[i].getAttribute('data-i18n');
if (els[i].tagName === 'TITLE') document.title = t(key);
else els[i].textContent = t(key);
}
var elsPh = document.querySelectorAll('[data-i18n-ph]');
for (var j = 0; j < elsPh.length; j++) {
elsPh[j].placeholder = t(elsPh[j].getAttribute('data-i18n-ph'));
}
var langBtns = document.querySelectorAll('.lang-btn');
for (var k = 0; k < langBtns.length; k++) {
if (langBtns[k].getAttribute('data-lang') === currentLang) langBtns[k].classList.add('active');
else langBtns[k].classList.remove('active');
}
renderNotes(); renderShop();
}
var langBtns = document.querySelectorAll('.lang-btn');
for (var l = 0; l < langBtns.length; l++) {
langBtns[l].onclick = function() { currentLang = this.getAttribute('data-lang'); localStorage.setItem('lang', currentLang); updateLanguage(); };
}
var THEMES=['beige','lavender','mint','terracotta','graphite'];
function applyTheme(theme,dark){
for(var i=0;i<THEMES.length;i++)document.body.classList.remove('theme-'+THEMES[i]);
document.body.classList.add('theme-'+theme);
if(dark)document.body.classList.add('dark');else document.body.classList.remove('dark');
document.getElementById('themeToggle').textContent=dark?'☀️':'🌙';
document.getElementById('darkModeSwitch').checked=dark;
var dots=document.querySelectorAll('.color-dot');
for(var j=0;j<dots.length;j++){
if(dots[j].getAttribute('data-theme')===theme)dots[j].classList.add('active');
else dots[j].classList.remove('active');
}
localStorage.setItem('theme',theme);localStorage.setItem('darkMode',dark?'1':'0');
}
var currentTheme=localStorage.getItem('theme')||'beige';
var isDark=localStorage.getItem('darkMode')==='1';
applyTheme(currentTheme,isDark);
document.getElementById('themeToggle').onclick=function(){isDark=!isDark;applyTheme(currentTheme,isDark)};
document.getElementById('darkModeSwitch').onchange=function(e){isDark=e.target.checked;applyTheme(currentTheme,isDark)};
var dots=document.querySelectorAll('.color-dot');
for(var d=0;d<dots.length;d++){
dots[d].onclick=function(){currentTheme=this.getAttribute('data-theme');applyTheme(currentTheme,isDark)};
}
var tabs=document.querySelectorAll('.tab');
for(var tab=0;tab<tabs.length;tab++){
tabs[tab].onclick=function(){
var allTabs=document.querySelectorAll('.tab');var allPanels=document.querySelectorAll('.panel');
for(var i=0;i<allTabs.length;i++)allTabs[i].classList.remove('active');
for(var i=0;i<allPanels.length;i++)allPanels[i].classList.remove('active');
this.classList.add('active');document.getElementById(this.getAttribute('data-panel')).classList.add('active');
};
}
var notes=JSON.parse(localStorage.getItem('notes')||'[]');
var shop=JSON.parse(localStorage.getItem('shop')||'[]');
var pendingReminder=null; var editId=null;
function saveNotes(){localStorage.setItem('notes',JSON.stringify(notes))}
function saveShop(){localStorage.setItem('shop',JSON.stringify(shop))}
document.getElementById('reminderToggle').onclick=function(e){
e.preventDefault();var panel=document.getElementById('reminderPanel');
if(panel.classList.contains('open')){panel.classList.remove('open');this.classList.remove('open')}
else{panel.classList.add('open');this.classList.add('open')}
};
var MONTHS_UK=['Січень','Лютий','Березень','Квітень','Травень','Червень','Липень','Серпень','Вересень','Жовтень','Листопад','Грудень'];
var MONTHS_EN=['January','February','March','April','May','June','July','August','September','October','November','December'];
var MONTHS_RU=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
function initDateSelectors(){
var months = currentLang === 'en' ? MONTHS_EN : (currentLang === 'ru' ? MONTHS_RU : MONTHS_UK);
var now=new Date();var year=now.getFullYear();
var ySel=document.getElementById('rYear');ySel.innerHTML='';
for(var y=year;y<=year+2;y++){var o=document.createElement('option');o.value=y;o.textContent=y;ySel.appendChild(o)}
var mSel=document.getElementById('rMonth');mSel.innerHTML='';
for(var m=0;m<12;m++){var o=document.createElement('option');o.value=m+1;o.textContent=months[m];mSel.appendChild(o)}
mSel.value=now.getMonth()+1;
function refreshDays(){
var y=parseInt(ySel.value,10),m=parseInt(mSel.value,10);
var daysInMonth=new Date(y,m,0).getDate();var dSel=document.getElementById('rDay');
var prev=parseInt(dSel.value,10)||1;dSel.innerHTML='';
for(var d=1;d<=daysInMonth;d++){var o=document.createElement('option');o.value=d;o.textContent=d;dSel.appendChild(o)}
dSel.value=Math.min(prev,daysInMonth);
}
ySel.onchange=refreshDays;mSel.onchange=refreshDays;refreshDays();
document.getElementById('rDay').value=now.getDate();
var hSel=document.getElementById('rHour');hSel.innerHTML='';
for(var h=0;h<24;h++){var o=document.createElement('option');o.value=h;o.textContent=(h<10?'0':'')+h;hSel.appendChild(o)}
hSel.value=now.getHours();
var minSel=document.getElementById('rMinute');minSel.innerHTML='';
for(var mi=0;mi<60;mi++){var o=document.createElement('option');o.value=mi;o.textContent=(mi<10?'0':'')+mi;minSel.appendChild(o)}
minSel.value=now.getMinutes();
}
initDateSelectors();
document.getElementById('setReminder').onclick=function(e){
e.preventDefault();
var y=parseInt(document.getElementById('rYear').value,10);
var m=parseInt(document.getElementById('rMonth').value,10);
var d=parseInt(document.getElementById('rDay').value,10);
var h=parseInt(document.getElementById('rHour').value,10);
var mi=parseInt(document.getElementById('rMinute').value,10);
var dt=new Date(y,m-1,d,h,mi);
if(dt<=new Date()){document.getElementById('reminderStatus').textContent=t('alertPast');return}
pendingReminder=dt;
var dateStr = dt.toLocaleString(currentLang === 'uk' ? 'uk-UA' : (currentLang === 'ru' ? 'ru-RU' : 'en-GB'));
document.getElementById('reminderStatus').innerHTML='✓ '+dateStr+' <button class="clear-reminder" id="clearReminder">'+t('alertRemove')+'</button>';
document.getElementById('reminderBadge').style.display='inline-block';
document.getElementById('clearReminder').onclick=function(ev){
ev.stopPropagation();pendingReminder=null;
document.getElementById('reminderStatus').textContent='';
document.getElementById('reminderBadge').style.display='none';
};
};
function renderNotes(){
var list=document.getElementById('notesList');
if(notes.length===0){list.innerHTML='<div class="empty">'+t('emptyNotes')+'</div>';return}
list.innerHTML='';
for(var i=0;i<notes.length;i++){
var n=notes[i];var div=document.createElement('div');div.className='card';
if(n.reminder&&new Date(n.reminder)<=new Date()&&!n.notified)div.classList.add('reminder-due');
var metaHtml=n.reminder?'<div class="meta">⏰ '+new Date(n.reminder).toLocaleString(currentLang === 'uk' ? 'uk-UA' : (currentLang === 'ru' ? 'ru-RU' : 'en-GB'))+'</div>':'';
div.innerHTML='<h3>'+(escapeHtml(n.title)||t('noTitle'))+'</h3><p>'+escapeHtml(n.body)+'</p>'+metaHtml+
'<div class="actions"><button class="icon-btn edit" data-edit="'+n.id+'" title="Edit">✏️</button><button class="icon-btn" data-del="'+n.id+'" title="Delete">🗑️</button></div>';
list.appendChild(div);
}
var delBtns=list.querySelectorAll('[data-del]');
for(var k=0;k<delBtns.length;k++){
delBtns[k].onclick=function(){
var id=parseInt(this.getAttribute('data-del'),10);var newNotes=[];
for(var i=0;i<notes.length;i++){if(notes[i].id!==id)newNotes.push(notes[i])}
notes=newNotes;saveNotes();renderNotes();
};
}
var editBtns=list.querySelectorAll('[data-edit]');
for(var e=0;e<editBtns.length;e++){
editBtns[e].onclick=function(){
var id=parseInt(this.getAttribute('data-edit'),10);
startEdit(id);
};
}
}
function startEdit(id){
var noteToEdit=null;
for(var i=0;i<notes.length;i++){if(notes[i].id===id)noteToEdit=notes[i]}
if(!noteToEdit)return;
editId=id;
document.getElementById('noteTitle').value=noteToEdit.title;
document.getElementById('noteBody').value=noteToEdit.body;
var btn=document.getElementById('addNote');
btn.textContent=t('btnSaveNote');
btn.classList.add('editing');
if(!document.getElementById('cancelEditBtn')){
var cancelBtn=document.createElement('button');
cancelBtn.id='cancelEditBtn';
cancelBtn.className='primary';
cancelBtn.style.background='var(--danger)';
cancelBtn.style.width='100%';
cancelBtn.style.marginTop='8px';
cancelBtn.textContent=t('btnCancel');
cancelBtn.onclick=function(){cancelEdit()};
document.getElementById('formActions').appendChild(cancelBtn);
}
if(noteToEdit.reminder){
var dt=new Date(noteToEdit.reminder);
pendingReminder=dt;
document.getElementById('reminderStatus').innerHTML='✓ '+dt.toLocaleString(currentLang === 'uk' ? 'uk-UA' : (currentLang === 'ru' ? 'ru-RU' : 'en-GB'))+' <button class="clear-reminder" id="clearReminder">'+t('alertRemove')+'</button>';
document.getElementById('reminderBadge').style.display='inline-block';
document.getElementById('clearReminder').onclick=function(ev){
ev.stopPropagation();pendingReminder=null;
document.getElementById('reminderStatus').textContent='';
document.getElementById('reminderBadge').style.display='none';
};
document.getElementById('reminderPanel').classList.add('open');
document.getElementById('reminderToggle').classList.add('open');
} else {
pendingReminder=null;
document.getElementById('reminderStatus').textContent='';
document.getElementById('reminderBadge').style.display='none';
document.getElementById('reminderPanel').classList.remove('open');
document.getElementById('reminderToggle').classList.remove('open');
}
window.scrollTo({top:0,behavior:'smooth'});
}
function cancelEdit(){
editId=null;
document.getElementById('noteTitle').value='';
document.getElementById('noteBody').value='';
var btn=document.getElementById('addNote');
btn.textContent=t('btnAddNote');
btn.classList.remove('editing');
var cancelBtn=document.getElementById('cancelEditBtn');
if(cancelBtn)cancelBtn.remove();
pendingReminder=null;
document.getElementById('reminderStatus').textContent='';
document.getElementById('reminderBadge').style.display='none';
document.getElementById('reminderPanel').classList.remove('open');
document.getElementById('reminderToggle').classList.remove('open');
initDateSelectors();
}
document.getElementById('addNote').onclick=function(e){
e.preventDefault();
var title=document.getElementById('noteTitle').value;
var body=document.getElementById('noteBody').value;
if(!title&&!body)return;
if(editId!==null){
for(var i=0;i<notes.length;i++){
if(notes[i].id===editId){
notes[i].title=title;
notes[i].body=body;
notes[i].reminder=pendingReminder?pendingReminder.toISOString():null;
notes[i].notified=false;
break;
}
}
cancelEdit();
} else {
notes.unshift({id:Date.now(),title:title,body:body,reminder:pendingReminder?pendingReminder.toISOString():null,notified:false});
saveNotes();
document.getElementById('noteTitle').value='';
document.getElementById('noteBody').value='';
document.getElementById('reminderStatus').textContent='';
document.getElementById('reminderBadge').style.display='none';
pendingReminder=null;initDateSelectors();
document.getElementById('reminderPanel').classList.remove('open');
document.getElementById('reminderToggle').classList.remove('open');
}
saveNotes();renderNotes();
};
function renderShop(){
var list=document.getElementById('shopList');
var clearWrapper=document.getElementById('clearBoughtWrapper');
var hasBought=false;
if(shop.length===0){list.innerHTML='<div class="empty">'+t('emptyShop')+'</div>';clearWrapper.style.display='none';return}
list.innerHTML='';

for(var i=0;i<shop.length;i++){
var item=shop[i];
if(item.done)hasBought=true;
var div=document.createElement('div');
div.className='shop-item'+(item.done?' done':'');
div.innerHTML = '<input type="checkbox" ' + (item.done ? 'checked' : '') + ' onchange="toggleShop(' + i + ', this)">' +
'<span class="shop-text">' + escapeHtml(item.text) + '</span>' +
'<button class="icon-btn" onclick="deleteShop(' + i + ')" title="Delete">🗑️</button>';
list.appendChild(div);
}
if(hasBought)clearWrapper.style.display='block'; else clearWrapper.style.display='none';
}

// Глобальні функції для чекбоксів та видалення
window.toggleShop = function(index, checkbox) {
shop[index].done = checkbox.checked;
saveShop();
var parentDiv = checkbox.closest('.shop-item');
if (checkbox.checked) {
parentDiv.classList.add('done');
} else {
parentDiv.classList.remove('done');
}
var hasBought = false;
for (var i = 0; i < shop.length; i++) { if (shop[i].done) { hasBought = true; break; } }
var clearWrapper = document.getElementById('clearBoughtWrapper');
if (hasBought) clearWrapper.style.display = 'block';
else clearWrapper.style.display = 'none';
};

window.deleteShop = function(index) {
shop.splice(index, 1);
saveShop();
renderShop();
};

// ДОДАВАННЯ ТОВАРУ
document.getElementById('addShop').onclick=function(e){
e.preventDefault();
var text=document.getElementById('shopInput').value;
if(!text)return;
shop.push({id:Date.now(),text:text,done:false});saveShop();
document.getElementById('shopInput').value='';renderShop();
};

// ОЧИЩЕННЯ КУПЛЕНИХ
document.getElementById('clearBoughtBtn').onclick=function(){
var newShop=[];
for(var i=0;i<shop.length;i++){if(!shop[i].done)newShop.push(shop[i])}
shop=newShop;saveShop();renderShop();
};

// ДОДАВАННЯ ПО ENTER
document.getElementById('shopInput').onkeydown=function(e){
if(e.key==='Enter'||e.keyCode===13){e.preventDefault();document.getElementById('addShop').click()}
};

// УТИЛІТА
function escapeHtml(s){
if(!s)return '';
return s.replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]});
}

updateLanguage();
});