import { readFileSync, writeFileSync, existsSync } from 'node:fs';

const manifestPath = new URL('../android/app/src/main/AndroidManifest.xml', import.meta.url);
if (!existsSync(manifestPath)) {
  throw new Error('AndroidManifest.xml was not found. Run "npx cap add android" first.');
}
let xml = readFileSync(manifestPath, 'utf8');
const permission = '    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />';
if (!xml.includes('android.permission.SCHEDULE_EXACT_ALARM')) {
  xml = xml.replace('<application', `${permission}\n    <application`);
  writeFileSync(manifestPath, xml);
}
