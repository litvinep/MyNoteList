import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  BannerAdSize,
  BannerAdPosition,
  BannerAdPluginEvents
} from '@capacitor-community/admob';

// Development build: Google demo banner is used to avoid invalid ad activity.
// Switch USE_TEST_ADS to false only after consent/privacy setup and before release.
const USE_TEST_ADS = true;
const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/9214589741';
const LIVE_BANNER_ID = 'ca-app-pub-5623976541315844/2995022828';

async function startAdMobBanner() {
  if (!Capacitor.isNativePlatform()) return;

  try {
    await AdMob.initialize();

    await AdMob.addListener(BannerAdPluginEvents.SizeChanged, (size) => {
      // The native banner overlays the WebView, so reserve space for it.
      document.body.style.paddingBottom = `${Math.max(40, size.height + 12)}px`;
    });

    await AdMob.addListener(BannerAdPluginEvents.FailedToLoad, (error) => {
      console.warn('AdMob banner failed to load:', error);
    });

    await AdMob.showBanner({
      adId: USE_TEST_ADS ? TEST_BANNER_ID : LIVE_BANNER_ID,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: USE_TEST_ADS
    });
  } catch (error) {
    // Advertising must never prevent notes, lists, or reminders from working.
    console.warn('AdMob initialization/banner error:', error);
  }
}

window.addEventListener('load', () => {
  startAdMobBanner();
}, { once: true });
