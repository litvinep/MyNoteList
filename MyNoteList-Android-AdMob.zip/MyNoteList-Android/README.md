# MyNoteList — Android / Capacitor project

This is the first Android-ready project structure for MyNoteList. It preserves the existing interface and data model and adds a Capacitor Local Notifications bridge for Android reminders.

## Project contents

- `www/index.html` — current app page and its existing inline interface logic.
- `www/native-reminders.js` — Android local-notification adapter.
- `www/manifest.json`, `www/sw.js`, `www/style.css`, icons — retained source assets from the web project.
- `reference/app.js` — the separate `app.js` file from the archive. The supplied `index.html` already contains its own inline app logic and does not load this file; it is kept here as a reference, not bundled as a second runtime script.
- `capacitor.config.json` — Capacitor app configuration.
- `.github/workflows/build-android.yml` — cloud workflow that builds a debug APK in GitHub Actions.

## Build locally

Requires Node.js 22, Java 21 and Android SDK:

```bash
npm install
npm run build
npx cap add android
node scripts/patch-android-manifest.mjs
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is created at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Build without a computer

1. Create a GitHub repository and upload the contents of this folder to its `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build MyNoteList APK** and press **Run workflow**.
4. When the workflow completes, open its run and download the `MyNoteList-debug-apk` artifact.

The workflow creates the Android project in the cloud, so the generated `android/` directory does not need to be uploaded.

## Important notes

- The application ID `ua.mynotelist.app` is provisional. It should be checked and kept consistent before publishing on Google Play; changing it later creates a different Android app identity.
- Android 13+ asks for notification permission. If the user denies it, reminders cannot be shown.
- Android 12+ may require the user to allow exact alarms in system settings for reminders to fire at an exact minute. The project adds `SCHEDULE_EXACT_ALARM`; Android can still restrict exact alarms according to system settings and battery policies.
- This is a debug-build setup, not a Play Store release/signing setup.
- The notification integration is a first implementation and must be tested on the target Motorola phone, including app closure, reboot, denied permissions, edits and deletion of reminders.

## AdMob banner integration

- The Android build includes `@capacitor-community/admob`.
- The AdMob application ID is added to the generated Android manifest by `scripts/patch-android-manifest.mjs`.
- `www/admob.js` places an adaptive banner at the bottom of the Android screen.
- Development builds intentionally use Google's official test banner ID. Do not click or test with live ads.
- Before publishing, complete the privacy policy and Google UMP consent flow where required, then change `USE_TEST_ADS` to `false` in `www/admob.js` and rebuild. The live banner unit ID is already recorded in that file.
