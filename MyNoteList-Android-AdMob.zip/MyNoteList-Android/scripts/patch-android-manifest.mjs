import { readFileSync, writeFileSync, existsSync } from 'node:fs';

const manifestPath = new URL('../android/app/src/main/AndroidManifest.xml', import.meta.url);
if (!existsSync(manifestPath)) {
  throw new Error('AndroidManifest.xml was not found. Run "npx cap add android" first.');
}

let xml = readFileSync(manifestPath, 'utf8');

const permission = '    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />';
if (!xml.includes('android.permission.SCHEDULE_EXACT_ALARM')) {
  xml = xml.replace('<application', `${permission}\n    <application`);
}

const appId = 'ca-app-pub-5623976541315844~2244213785';
const metadataName = 'com.google.android.gms.ads.APPLICATION_ID';
if (!xml.includes(metadataName)) {
  const metadata = `        <meta-data android:name="${metadataName}" android:value="${appId}" />\n`;
  xml = xml.replace('<application', `<application`);
  const applicationOpenEnd = xml.indexOf('>', xml.indexOf('<application'));
  if (applicationOpenEnd === -1) {
    throw new Error('Could not find the opening <application> tag.');
  }
  xml = xml.slice(0, applicationOpenEnd + 1) + '\n' + metadata.trimEnd() + xml.slice(applicationOpenEnd + 1);
}

writeFileSync(manifestPath, xml);
